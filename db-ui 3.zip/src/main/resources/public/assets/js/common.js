$(document).ready(function() {

	$('#logout-btn').click(function() {
		window.location.replace('/db/logout');
	});
});

function hasOverflow(element) {
	return (element.offsetHeight < element.scrollHeight 
			|| element.offsetWidth < element.scrollWidth);
}

function objectifyForm(formArray) {// serialize data function

	var returnArray = {};
	for (var i = 0; i < formArray.length; i++) {
		returnArray[formArray[i]['name']] = formArray[i]['value'];
	}
	return returnArray;
}
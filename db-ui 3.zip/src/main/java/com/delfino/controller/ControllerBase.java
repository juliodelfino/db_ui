package com.delfino.controller;

public abstract class ControllerBase {

}

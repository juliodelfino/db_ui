package com.delfino.controller;

import com.delfino.util.ViewUtil;

import spark.Route;

public class LoginController extends ControllerBase {

	private Route getIndex = (req, res) -> {


	    return ViewUtil.render(null, "home.html");
	};
	

}

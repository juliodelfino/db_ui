
var databases = null;

$(document).ready(function() {

	initDatabases();

    $("#db-connect-form").submit(function(e){
        e.preventDefault();
        $.post("/db/connectdb", $(this).serialize(), function(result){

            alert(JSON.parse(result) ? "Successfully connected" : "Failed");
        });
    });

});

function initDatabases() {

  	$.get("/db/alldb", function(result){
        databases = JSON.parse(result);
        $.each(databases, function(i, val) {

             var tabId = 'tab_' + val.connectionName;
             var headerId = 'header_' + val.connectionName;
             $('#myTab li').before(
                '<li class="nav-item"><a href="#' + tabId + '" id="' + headerId
                    + '" data-toggle="tab" aria-controls="' + tabId + '" >'
                    + val.connectionName + '</a></li>');
             $('.tab-content').append('<div class="tab-pane" id="' + tabId
                + '" role="tabpanel" aria-labelledby="' + headerId + '"></div>');

             $('#' + headerId).click(loadTableView);
        });
  	});
}

function loadTableView() {

    var tabPanel = $(this).attr("href");
    $(tabPanel).html('<div><img class="center-block" src="/assets/images/fluid-loader.gif"/></div>');
  	$.get("/db/tableview", function(result){
        $(tabPanel).html(result);
        initTableActions(tabPanel);
  	});
}

function initTableActions(tabPanel) {

	$(tabPanel + ' #exec-btn').click(function(){
		executeQuery($(tabPanel + ' #qbox').val());
	});

	$('.nav-sidebar li a').click(function(){
        $('#table-name').html($(this).html());
	});
}

function executeQuery(sql) {

	var dbtable_url = "/db/query?q=" + sql;
  	$.get(dbtable_url, function(result){

  		result = JSON.parse(result);
  		var tableHeaders = '';
  		$.each(result.columns, function(i, val) {
  		    tableHeaders = tableHeaders + '<th>' + val.title + '</th>';
  		});

  		$('#admin_tbl thead tr').html(tableHeaders);

  		table = $('#admin_tbl').DataTable({

  			destroy: true,
			columns: result.columns,
			data: result.data
		});
  	});
}

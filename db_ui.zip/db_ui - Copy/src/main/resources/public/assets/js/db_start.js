
$(document).ready(function() {

    $('#login-btn').click(function(){

        var user = $('#user-box').val();
        login(user);
    });

    $("#login-form").submit(function(e){
        e.preventDefault();
        var user = $('#user-box').val();
        login(user);
    });
	
});

function login(username) {

    $.post("/db/login", {user: username}).done( function(result){

        alert(JSON.parse(result) ? "Successfully logged in" : "Please request OIL team");
    });
}

package com.delfino.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.delfino.dao.DbInfoDao;
import com.delfino.dao.UserDao;
import com.delfino.model.DbInfo;
import com.delfino.util.Pair;
import com.delfino.util.RequestUtil;
import com.delfino.util.ViewUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import spark.Route;

public class DbController extends ControllerBase {

	private UserDao userDao = new UserDao();
    private DbInfoDao dbDao = new DbInfoDao();
    private Gson gson = new GsonBuilder().setPrettyPrinting().create();

	public DbController() throws ClassNotFoundException {

//	    Class.forName("com.mysql.jdbc.Driver");
//		Class.forName("org.apache.phoenix.jdbc.PhoenixDriver");

	}
	
	private Route getIndex = (req, res) -> {

		return ViewUtil.render("db.html");
	};

    private Route postLogin = (req, res) -> {
        return userDao.validate(req.queryParams("user"));
    };

    private Route postConnectDb = (req, res) -> {

        return dbDao.add(RequestUtil.extract(req, DbInfo.class));
    };

    private Route getAllDb = (req, res) -> {

        return gson.toJson(dbDao.getAll());
    };

    private Route getTableView = (req, res) -> {

        Map map = new HashMap();
        map.put("tables", dbDao.getDb("HDP4001").getDbMetadata());
        return ViewUtil.render(map,"db_table_view.html");
    };

    private Route getStart = (req, res) -> {

        return ViewUtil.render("db_start.html");
    };

	private Route getQuery = (req, res) -> {

	    String sql = req.queryParams("q");
	    return dbDao.getDb("HDP4001").executeQuery(sql);
	};
}

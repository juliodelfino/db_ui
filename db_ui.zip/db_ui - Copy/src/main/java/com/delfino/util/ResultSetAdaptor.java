package com.delfino.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ResultSetAdaptor {

    private ObjectMapper mapper = new ObjectMapper();

    public String convert(ResultSet resultSet) throws SQLException, JsonProcessingException {

        List<Map.Entry> columns = new ArrayList<Map.Entry>();
        List data = new ArrayList<>();

        ResultSetMetaData metaData = resultSet.getMetaData();
        for (int i = 1; i <= metaData.getColumnCount(); i++) {
            String columnName = metaData.getColumnName(i);
            columns.add(new Pair("title", columnName));
        }

        while (resultSet.next()) {
            List row = new ArrayList<>();

            for (int i = 1; i <= metaData.getColumnCount(); i++) {
                row.add(resultSet.getObject(i));
            }

            data.add(row);
        }

        Map resultMap = new HashMap();
        resultMap.put("columns", columns);
        resultMap.put("data", data);

        return mapper.writeValueAsString(resultMap);
    }
}

package com.delfino.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import spark.ModelAndView;
import spark.template.velocity.VelocityTemplateEngine;
import spark.utils.IOUtils;

public class ViewUtil {
	
	public static String STATIC_FILES = "/public";

	private static String VIEWS = STATIC_FILES + "/views";


	
    public static String render(Map<String, Object> model, String templatePath) {
        model.putAll((Map)AppProperties.getInstance());
        return new VelocityTemplateEngine().render(
        		new ModelAndView(model, VIEWS + "/" + templatePath));
    }

	public static Object render(String templatePath) throws IOException {
		return new VelocityTemplateEngine().render(
			new ModelAndView((Map)AppProperties.getInstance(), VIEWS + "/" + templatePath));
	}

//	public static Object renderHtml(String htmlPath) throws IOException {
//		return IOUtils.toString(ViewUtil.class.getResourceAsStream(
//				STATIC_FILES + "/" + htmlPath));
//	}
}

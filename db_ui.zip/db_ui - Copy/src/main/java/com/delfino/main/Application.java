package com.delfino.main;

import static spark.Spark.get;
import static spark.Spark.post;
import static spark.Spark.initExceptionHandler;
import static spark.Spark.port;
import static spark.Spark.staticFiles;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import com.delfino.controller.DbController;
import com.delfino.controller.MainController;
import com.delfino.util.ViewUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import spark.Route;

public class Application {

    private static final Logger LOGGER = LoggerFactory.getLogger(Application.class);

	public static void main(String[] args) throws ReflectiveOperationException {
		port(3001);
		initExceptionHandler((e) -> {
			System.out.println("uh-oh");
			e.printStackTrace();
			System.exit(100);
		});

		staticFiles.location(ViewUtil.STATIC_FILES);

		setupRoutes(MainController.class, DbController.class);

	}

	private static void setupRoutes(Class... controllers) throws ReflectiveOperationException {

		for (Class controllerClass : controllers) {

			Object instance = controllerClass.newInstance();
			String module = controllerClass.getSimpleName().replace("Controller", "").toLowerCase();
			module = module.equals("main") ? "" : "/" + module;
			for (Field f : controllerClass.getDeclaredFields()) {
				if (f.getType().equals(Route.class)) {

					f.setAccessible(true);
					String name = f.getName().toLowerCase();
					if (name.startsWith("get")) {
						name = name.replace("get", "");
						name = name.equals("index") ? "" : "/" + name;
						String path = module + name;
                        LOGGER.info("Added route GET " + path);
						get(path, (Route) f.get(instance));
					}
					else if (name.startsWith("post")) {
						name = name.replace("post", "");
						name = name.equals("index") ? "" : "/" + name;
                        String path = module + name;
                        LOGGER.info("Added route POST " + path);
						post(path, (Route) f.get(instance));
					} else {
					    throw new IllegalStateException(controllerClass + "." + f.getName()
                            + ": invalid route name. "
                            + "route names must start with either 'get' or 'post'");
                    }
				}
			}
		}
	}
}

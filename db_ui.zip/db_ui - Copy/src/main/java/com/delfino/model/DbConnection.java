package com.delfino.model;

import com.delfino.util.ResultSetAdaptor;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DbConnection {

    private ResultSetAdaptor adaptor = new ResultSetAdaptor();
    private DbInfo dbInfo;
    Connection conn = null;
    Statement stmt;

    public DbConnection(DbInfo dbInfo) throws SQLException {
        this.dbInfo = dbInfo;
        conn = DriverManager
            .getConnection(dbInfo.getUrl(),dbInfo.getUsername(), dbInfo.getPassword());
    }

    public String executeQuery(String sql) throws SQLException  {

        ResultSet rs = null;
        String result = "";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            result = adaptor.convert(rs);
        } catch(Exception ex) {
            ex.printStackTrace();
        }

        finally {
            rs.close();
            conn.close();
        }

        return result;
    }

    public List getDbMetadata() throws SQLException {
        DatabaseMetaData md = conn.getMetaData();
        List tables = new ArrayList();
        ResultSet rs = md.getTables(null, null, "%", null);
        while (rs.next()) {
            tables.add(rs.getString(3));
        }
        rs.close();
        return tables;
    }
}

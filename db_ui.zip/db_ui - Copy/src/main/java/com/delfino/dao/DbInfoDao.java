package com.delfino.dao;

import com.delfino.model.DbConnection;
import com.delfino.model.DbInfo;
import com.delfino.util.AppProperties;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class DbInfoDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(AppProperties.class);

    private AppProperties props = AppProperties.getInstance();
    private String jsonFile = props.getProperty("data_dir") + "/dbconn.json";
    private Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public List<DbInfo> getAll(){

        DbInfo[] dbconns = null;
        File f = new File(jsonFile);
        if (f.exists()) {
            try (JsonReader reader = new JsonReader(new FileReader(f))) {
                dbconns = gson.fromJson(reader, DbInfo[].class);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return dbconns != null ? new ArrayList(Arrays.asList(dbconns)) : new ArrayList();
    }

    public boolean getD(String user){
        return getAll().contains(user);
    }

    public boolean add(DbInfo dbConn){
        List dbconns = getAll();
        try {
            if (dbConn.getConnectionName() == null) {
                dbConn.setConnectionName(UUID.randomUUID().toString().substring(0,8));
            }
            dbconns.add(dbConn);
            FileUtils.write(new File(jsonFile), gson.toJson(dbconns));
            return true;
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
        }
        return false;
    }

    public DbConnection getDb(String connectionName) throws SQLException {

        return new DbConnection(getAll().get(0));
    }
}

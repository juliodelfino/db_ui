package com.delfino.dao;

import com.delfino.util.AppException;
import com.delfino.util.AppProperties;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class UserDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(AppProperties.class);

    private AppProperties props = AppProperties.getInstance();
    private String jsonFile = props.getProperty("data_dir") + "/users.json";
    private Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public List getUsers(){

        List users = null;
        File f = new File(jsonFile);
        if (f.exists()) {
            try (JsonReader reader = new JsonReader(new FileReader(f))) {
                users = gson.fromJson(reader, List.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return users != null ? users : new ArrayList();
    }

    public boolean validate(String user){
        return getUsers().contains(user);
    }

    public boolean addUser(String user){
        List users = getUsers();
        try {
            if (users.contains(user)) {
                throw new AppException(String.format("user '%s' already exists", user));
            }
            users.add(user);
            FileUtils.write(new File(jsonFile), gson.toJson(users));
            return true;
        } catch (IOException | AppException e) {
            LOGGER.error(e.getMessage(), e);
        }
        return false;
    }

}

package com.delfino.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MapUtils;

import spark.ModelAndView;
import spark.Request;
import spark.template.velocity.VelocityTemplateEngine;
import spark.utils.IOUtils;

public class ViewUtil {
	
	public static String STATIC_FILES = "/public";

	private static String VIEWS = STATIC_FILES + "/views";
	
    public static String render(Request req, Map<String, Object> model, String templatePath) {
        model.putAll((Map)AppProperties.getInstance());
        req.session().attributes().stream().forEach(
        		attr -> model.put(attr, req.session().attribute(attr)));
        return new VelocityTemplateEngine().render(
        		new ModelAndView(model, VIEWS + "/" + templatePath));
    }

	public static String render(Request req, String templatePath) throws IOException {
		return render(req, new HashMap(), templatePath);
	}

//	public static Object renderHtml(String htmlPath) throws IOException {
//		return IOUtils.toString(ViewUtil.class.getResourceAsStream(
//				STATIC_FILES + "/" + htmlPath));
//	}
}

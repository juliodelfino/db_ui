
var databases = null;
var connLoaderHtml = '<div><img class="center-block" src="/assets/images/fluid-loader.gif"/></div>';
var tableLoaderHtml = '<div><img class="center-block" src="/assets/images/loader1.gif"/></div>';

$(document).ready(function() {

	initDatabases();

    $("#db-connect-form").submit(function(e){
        e.preventDefault();
        $('#conn-loading-icon img').show();
        $.post("/db/connectdb", $(this).serialize(), function(result){

            $('#conn-loading-icon img').hide();
        	result = JSON.parse(result);
        	if (result.error) {
        		alert(result.message);
        	} else {
        		var tabHeaderId = addTab(result);
        		$('#' + tabHeaderId).trigger('click');
        		$('#db-connect-form').trigger('reset');
        	}
        });
    });

});

function initDatabases() {

  	$.get("/db/alldb", function(result){
        databases = JSON.parse(result);
        $.each(databases, function(i, val) {
        	 addTab(val);
        });
  	});
}

function addTab(dbInfo) {
	var connName = dbInfo.connectionName.replace(/\s+/g, '_').toLowerCase();
    var tabId = 'tab_' + connName;
    var headerId = 'header_' + connName;
    $('#myTab li:last').after(
       '<li class="nav-item"><a href="#' + tabId + '" id="' + headerId
           + '" data-toggle="tab" aria-controls="' + tabId + '" >'
           + dbInfo.connectionName + '</a></li>');
    $('.tab-content').append('<div class="tab-pane" id="' + tabId
       + '" role="tabpanel" aria-labelledby="' + headerId 
       + '" data-conn-id="' + dbInfo.connectionName + '"></div>');

    $('#' + headerId).click(loadSchemaView);
    return headerId;
}

function loadSchemaView() {

    var tabPanel = $(this).attr("href");
    if ($(tabPanel).html().length == 0) {
        $(tabPanel).html(connLoaderHtml);
      	$.get("/db/tableview", {connId: $(tabPanel).data("connId")}, function(result){
            $(tabPanel).html(result);
            initTableActions(tabPanel);
      	});
    }
}

function initTableActions(tabPanel) {
	
	$(tabPanel + ' .q-columns-btn').click(function(){
		var tableName = $(tabPanel + ' .table-select').val();
		$('#qbox').val('');
		getColumns(tableName, tabPanel);
	});
	
	$(tabPanel + ' .q-rowcount-btn').click(function(){
		var tableName = $(tabPanel + ' .table-select').val();
		var sql = 'SELECT COUNT(*) AS "COUNT" FROM ' + tableName;
		$('#qbox').val(sql);
		$(tabPanel + ' .exec-sql-form').trigger('submit');
	});
	
	$(tabPanel + ' .q-alldata-btn').click(function(){
		var tableName = $(tabPanel + ' .table-select').val();
		var sql = 'SELECT * FROM ' + tableName;
		$('#qbox').val(sql);
		$(tabPanel + ' .exec-sql-form').trigger('submit');
	});

	$(tabPanel + ' .exec-btn').click(function(){
		$(tabPanel + ' .exec-sql-form').trigger('submit');
	});
	
	$(tabPanel + ' .exec-sql-form').submit(function(e){
        e.preventDefault();
		executeQuery($(tabPanel + ' #qbox').val(), tabPanel);
	});
	
	$(tabPanel + ' .conn-info-btn').click(function(){

	  	$.get("/db/info", {connId: $(tabPanel).data("connId")}, function(result){

	  		result = JSON.parse(result);
	  		$('#conn-info-dialog input[name=connectionName]').val(result.connectionName);
	  		$('#conn-info-dialog input[name=url]').val(result.url);
	  		$('#conn-info-dialog input[name=username]').val(result.username);
			$('#conn-info-dialog #conn-id-dialog-header').html($(tabPanel).data('connId'));
			$('#conn-info-dialog').modal('show');
	  	});
	});

//	$('.nav-sidebar li a').click(function(){
//        $('#table-name').html($(this).html());
//	});
	
	
}

function getColumns(tableName, tabPanel) {

	$(tabPanel + ' .dynamic-table').html(tableLoaderHtml);
	var params = {
		connId: $(tabPanel).data("connId"),
		table: tableName
	};
  	$.get("/db/columns", params, function(result){
  		result = JSON.parse(result);
  		updateDynamicTable(result, tabPanel);
  	});
}

function executeQuery(sql, tabPanel) {

	$(tabPanel + ' .dynamic-table').html(tableLoaderHtml);
	var connId = $(tabPanel).data("connId");
	var params = {
		connId: $(tabPanel).data("connId"),
		q: sql
	};
  	$.get("/db/query", params, function(result){
  		result = JSON.parse(result);
  		if (result.error) {
  			displayError(result, tabPanel);
  		} else {
  	  		updateDynamicTable(result, tabPanel);
  		}
  	});
}

function updateDynamicTable(result, tabPanel) {

	var tableHeaders = '';
	$.each(result.columns, function(i, val) {
	    tableHeaders = tableHeaders + '<th>' + val.title + '</th>';
	});

	$(tabPanel + ' .dynamic-table').html(
			'<table><thead><tr>' + tableHeaders + '</tr></thead></table>');

	table = $(tabPanel + ' .dynamic-table table').DataTable({
		destroy: true,
		dom: 'Bfrtip',
		columns: result.columns,
		data: result.data,
        buttons: ['copy','csv']
	});
	
	$(tabPanel + ' .dynamic-table tbody tr td').dblclick(function(){
		if (hasOverflow($(this).get(0))) {
			$('#myModal .modal-body').html($(this).html());
			$('#myModal').modal('show');
		}
	});
}

function displayError(result, tabPanel) {

	$(tabPanel + ' .dynamic-table').html(
			'<div class="col-lg-12 alert alert-danger">' + result.message + '</div>');
}

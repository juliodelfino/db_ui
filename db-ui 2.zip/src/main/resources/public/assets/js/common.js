$(document).ready(function() {

	$('#logout-btn').click(function(){
		window.location.replace('/db/logout');
	});
});

function hasOverflow(element) {
	return (element.offsetHeight < element.scrollHeight
			|| element.offsetWidth < element.scrollWidth);
}

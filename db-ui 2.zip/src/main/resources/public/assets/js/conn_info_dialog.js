$(document).ready(function() {
	$('#update-dbinfo-btn').click(function(){
		$('#conn-info-dialog').modal('hide');
	});
	$('#delete-dbinfo-btn').click(function(){
		var confirmDelete = confirm("Deleting this database cannot be undone. Click OK to continue.");
		if (confirmDelete) {
			$('#conn-info-dialog').modal('hide');
		}
	});
});

function hasOverflow(element) {
	return (element.offsetHeight < element.scrollHeight
			|| element.offsetWidth < element.scrollWidth);
}
